package excercise1;

public class TestDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Test test1 = new Test();
		test1.inputAnswer();
	}

}
